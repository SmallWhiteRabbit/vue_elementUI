<template>
  <div>
    <iframe :src="url"></iframe>
  </div>
</template>

<script>
export default {
  data(){
    return{
      url:''
    }
  }
}
</script>

<style>

</style>